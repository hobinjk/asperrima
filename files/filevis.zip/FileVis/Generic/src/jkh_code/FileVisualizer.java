package jkh_code;

import java.io.File;
import java.io.PrintStream;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import processing.core.PApplet;
import processing.core.PFont;

public class FileVisualizer extends PApplet {
	private static final long serialVersionUID = 1L;
	public static void main( String[] args ) {
		String[] argsn = new String[args.length+1];
		for( int i = 0; i < args.length; i++ ) {
			argsn[i+1] = args[i];
			System.out.println(args[i]);
		}
		argsn[0] = "jkh_code.FileVisualizer";
		PApplet.main( argsn );
	}
	
	private SizeQuery sq;
	private Thread sqThread;
	public static ThreadPoolExecutor es; 
	public static AtomicInteger threadCount;
	public static long fileCount;
	
	private float r;
	public static PrintStream out;
	private static int THREAD_COUNT = 4;
	long start, end = 0;
	public void setup() {
		size(400,400);
		r = width/2;
		start = System.currentTimeMillis();
		
		es =  (ThreadPoolExecutor) Executors.newFixedThreadPool( THREAD_COUNT ); //512 kills the compy
		threadCount = new AtomicInteger(0);
		//try {
			out = System.out;//new PrintStream( new File( "./log.log"));
		//} catch( IOException e ) {
		//	System.err.println("unable to open log file, derp");
		//	System.exit( -1 );
		//}
		//es = (ThreadPoolExecutor) Executors.newCachedThreadPool();
		File fname = File.listRoots()[0];
		if( args.length > 0 ) fname = new File( args[0] );
		
		//fname = new File( File.listRoots()[0] );
		sq = new SizeQuery( null, fname, 0 );
		
		colorMode( HSB, 360, 255, 255, 255 );
		textFont( createFont( PFont.list()[0], 12 ));
		
		sqThread = new Thread( sq );
		sqThread.start();
		
		smooth();
	}
	public void draw() {
		if( sq.done ) {
			if( end == 0 ) {
				end = System.currentTimeMillis();
				System.out.println("That took "+(end-start)/1000.0 +" seconds");
			}
			
			float t = 0;
			pushMatrix();
			translate(width/2,height/2);
			for( int i = 0; i < sq.children.length; i++ ) {
				fill( (360*(float)i/(float)sq.children.length)%360, 255, 255, 255 );
				stroke(0,0,0);
				float tp = t + ((float)sq.children[i].size/(float)sq.size)*2*(float)Math.PI;
				//let's add 1/16th's padding!
				float pad = 1/320.0f;
				arc( 0, 0, r*2, r*2, t+pad, tp-pad);
				line( 0,0, r*cos(t+pad), r*sin(t+pad));
				line( 0,0, r*cos(tp-pad), r*sin(tp-pad));
				
				//if( sq.sizes[i] == 0 ) System.out.println("ewwww: "+sq.children[i].getPath());
				fill(0);
				pushMatrix();
				
				String str = sq.children[i].name+": "+formattedSize(sq.children[i].size);
				while( textWidth( str ) > r ) str = str.substring(0,str.length()-2);
				float remap = ((t+tp)/2+2*PI)%(2*PI);
				if(remap > Math.PI/2 && remap < 3*Math.PI/2) {
					stroke(0,0,127);
					textAlign( LEFT, CENTER );
					rotate((t+tp)/2+PI);
					translate( -r + 8, 0 );
				} else {
					stroke(0,0,255);
					textAlign( RIGHT, CENTER );
					rotate((t+tp)/2);
					translate( r - 8, 0 );
				}
				text( str, 0, 0 );
				popMatrix();
				t = tp;
			}
			textAlign(LEFT,TOP);
			stroke(0,0,255);
			text(formattedSize(sq.size),0,0);
			popMatrix();
			
		} else {
			//System.out.println(es.getActiveCount()+":"+es.getCompletedTaskCount()+":"+es.getCorePoolSize());
			background(0);
			stroke(120,255,255,255);
			fill(120,255,255,255);
			textAlign( PApplet.CENTER, PApplet.CENTER );
			text( ""+fileCount, width/2, height/2 );
		}
	}
	private String formattedSize(long l_) {
		int i = 0;
		double l = l_;
		String[] reps = {
				"B",
				"KB",
				"MB",
				"GB",
				"TB",
				"PB"
		};
		while( l > 1000 && ++i < reps.length ) { 
			l /= 1000;
		}
		
		return String.format( "%.2f %s", l, reps[i] );
	}
	public void mousePressed()  {
		if(! sq.done ) return;
		
		float r = (float) ((float)(Math.atan2( mouseY - height/2, mouseX - width/2 )+2*Math.PI)%((float)2*Math.PI));
		float t = 0;
		if( mouseButton == RIGHT && sq.parent != null ) {
			sq = sq.parent;
			return;
		} else {
			System.out.println(sq.parent+":"+(mouseButton==RIGHT));
		}
		System.out.println("there are "+sq.children.length+"children");
		for( int i = 0; i < sq.children.length; i++ ) {
			float tp = t + ((float)sq.children[i].size/(float)sq.size)*2*(float)Math.PI;
			
			if( r < tp && r > t ) {
				sq = sq.children[i];
				return;
			}
			t = tp;
		}
		
	}
	@Override
	public void exit() {
		es.shutdown();
		try {
			if( es.awaitTermination( 1, TimeUnit.SECONDS )) {
				System.out.println("IT IS DEAD");
			} else {
				es.shutdownNow();
				if( es.awaitTermination( 1, TimeUnit.SECONDS )) {
					System.out.println("it's pretty strong");
				}
			}
		} catch (InterruptedException e) {
			System.out.println("BAD BAD BAD");
			e.printStackTrace();
		}
		try {
			sqThread.join(1);
		} catch (InterruptedException e) {
			System.out.println("IT SHALL DIE");
		}
		es = null;
		System.out.println("exited without any errors?");
		super.exit();
	}
	public static  boolean queryThreadAvailability( int threads ) {
		if( threadCount.get() + threads <= es.getMaximumPoolSize() ) {
			threadCount.addAndGet(threads);
			return true;
		}
		return false;
	}
}