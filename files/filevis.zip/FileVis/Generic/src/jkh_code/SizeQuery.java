package jkh_code;

import java.io.File;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class SizeQuery implements Callable<SizeQuery>, Future<SizeQuery>, Runnable {
	private File file;
	public SizeQuery parent;
	public int index;
	public long size;
	public SizeQuery[] children;
	public boolean done;
	public String name;
	/*
	public SizeQuery( String name ) {
		System.out.println("name: "+name);
		file = new File( name );
		this.name = name;
		done = started = false;
		fileCount = BigInteger.valueOf(1);
		index = 0;
	}
	*/
	public SizeQuery(SizeQuery parent_, File file_, int index_) {
		file = file_;
		name = file.getName();
		index = index_;
		done = false;
		parent = parent_;
	}
	
	public void run() {
		try {
			call( );
		} catch (Exception e) {
			System.out.println("somethingsies went wrongsies");
			e.printStackTrace();
		}
	}
	

	@Override
	public boolean cancel(boolean arg0) {
		return false;
	}

	@Override
	public SizeQuery get() throws InterruptedException, ExecutionException {
		try {
			return call();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public SizeQuery get(long arg0, TimeUnit arg1) throws InterruptedException,
			ExecutionException, TimeoutException {
		return get();
	}
	public boolean isCancelled() {
		return false;
	}
	public boolean isDone() {
		return true;
	}
	public SizeQuery call() throws Exception {
		size = 0;
		//FileVisualizer.out.println("started "+file.getPath());
		if(! file.exists() )
			return this;
		if( file.isFile() ) {
			FileVisualizer.fileCount += 1;
			this.size = file.length();
			return this;
		}
		if( file.listFiles() == null || file.listFiles().length == 0 )
			return this;
		if(! file.getAbsolutePath().equals( file.getCanonicalPath() )) //oh look it checks for links
			return this;
		File[] tf = file.listFiles(); 
		
		//long len = tf.length;
		children = new SizeQuery[tf.length];
		LinkedList<Future<SizeQuery>> execs = new LinkedList<Future<SizeQuery>>(); //this will soon make sense maybe; //this will soon make sense maybe
		
		for( int i = 0; i < tf.length; i++ ) {
			boolean thread = FileVisualizer.queryThreadAvailability( 1 ); 
			children[i] = new SizeQuery( this, tf[i], i );//fileCount.multiply(BigInteger.valueOf(len)) );
			if( thread ) execs.add( FileVisualizer.es.submit( (Callable<SizeQuery>)children[i] ) );
			else execs.add( children[i] );
		}
		//System.out.println("before: "+parent.es.getActiveCount());
		ListIterator<Future<SizeQuery>> iter = execs.listIterator();
		while( execs.size() > 0 ) {
			if(! iter.hasNext() ) iter = execs.listIterator();
			Future<SizeQuery> future = iter.next();
			if( !future.isDone() ) continue;
			try {
				SizeQuery sq = future.get();
				size += sq.size; //heh
			} catch( Exception e ) {
				FileVisualizer.out.println("it's that other one (sq)" );
				e.printStackTrace();
				System.exit(-1);
			}
			iter.remove();
		}
		done = true;
		//System.out.println("after: "+parent.es.getActiveCount());
		//FileVisualizer.out.println("finished "+file.getPath());
		return this;
	}
}