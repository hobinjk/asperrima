#include "perm.h"


char** dict = NULL;
int dict_len = 0;

void load_dict( ) {
    int lines = 0;
    FILE* infd = fopen("evenbetter.txt", "r");
    char* in;
    int c, i, line;
    int len;
    fseek( infd, 0, SEEK_END );
    len = ftell( infd );
    fseek( infd, 0, SEEK_SET );
    //printf( "len: %d\n", len );
    in = malloc( len );
    
    fread( in, 1, len, infd );
    fclose( infd );
    for( i = 0; i < len; i++ ) {
        if( in[i] == '\n' ) lines++;
    }
    dict = malloc( sizeof(char*) * lines );
    //printf( "THERE ARE %d LIGHTS--I MEAN LINES\n", lines );
    i = 0;
    for( line = 0; line < lines; line++ ) { 
        int slen = 0;
        while( in[i+slen] != '\n' ) {
            slen++;
        }
        dict[line] = malloc(slen+1);
        memcpy( dict[line], in+i, slen );
        int j;
        for( j = 0; j < slen; j++ )
            dict[line][j] = tolower( dict[line][j] );
        dict[line][slen] = '\0';
        ////printf( "dict[%d][0:%d]: %s\n", line, slen, dict[line] );
        i = i + slen + 1;
        if( i >= len ) break;
    }
    dict_len = lines;
    free( in );
}
void print_hex( unsigned char* dat, int dat_len ) { 
    int i;
    for( i = 0; i < dat_len; i++ ) {
        printf( "%02X", (int)dat[i] );
        //if( (i % 8 == 0) && (i > 0) ) //printf( "\n" );
    }
}
int decrypt_check( unsigned char *ciphertext, int ciphertext_len, unsigned char *key_data, int key_data_len, unsigned char *salt ) {
    EVP_CIPHER_CTX ctx;
    decrypt_init( key_data, key_data_len, salt, &ctx );
    int c_len = ciphertext_len;
    char* plaintext = (char*)aes_decrypt( &ctx, ciphertext, &c_len );
//    print_hex( plaintext, c_len );
//    printf( "%s\n", plaintext );
    EVP_CIPHER_CTX_cleanup( &ctx );
    float wordper = words(plaintext,c_len);
    //if( strncmp( key_data, "school", key_data_len ) == 0 ) printf( "%s: %f %s\n", key_data, wordper, plaintext );
    if( wordper > 0.5f ) {
//        printf( "%f: %s\n", wordper, key_data );
    }
    free( plaintext );
    return wordper > 0.5f;
}
float words( char* text, int len ) {
    int i, start = 0, wordcount = 0, spacecount = 1;

    for( i = 1; i < len; i++ ) {
        if( text[i] != ' ' ) continue;
        spacecount ++;
        //printf( "space: %d:%d\n", start, i );

        if( word( text, start, i ) ) {
            //printf( "word: %d:%d\n", start, i );
            wordcount ++;
        }
        start = i+1;
        
    }
    float per = (float)wordcount/(float)spacecount;

    return per;
}
int word( char* test, int start, int end ) {
    //binary search or something
    //word = test[lo:hi-1] inclusive
    char* word = test+start;
    int len = end-start; //eh
//    char* derp = malloc( len+1 );
    int hi = dict_len-1, mid, lo=0;
//    strncpy( derp, word, len );
    int i;
    for( i = 0; i < len; i++ )
        word[i] = tolower( word[i] );
//    derp[len] = '\0';
    while( lo < hi ) {
        mid = (lo+hi)/2;
        
        int cmp = streq( dict[mid], test, len );
        //printf( "%d = eq( \"%s\", \"%s\" );\n", cmp, dict[mid], derp );
        if( cmp == 0 ) break;
        else if( cmp < 0 )
            lo = mid + 1;
        else
            hi = mid - 1;
    }
    
    if( lo >= hi ) {
        //printf("not a word: %s\n", derp);
        return 0;
    }
    //printf("a word: t%st\n", derp);
//    free( derp );
    return 1;
}
int streq( char* dict_word, char* test, int test_len  ) {

    return strncmp( dict_word, test, test_len );
    /*
    int ret = 0;
    int i;
    int dict_len = strlen( dict_word );
    if( dict_len != test_len ) {
        return test_len-dict_len;
    }
    for( i = 0; i < test_len; i++ ) {
        test[i] = tolower( test[i] );
        //if( i >= dict_len ) return -test[i]; //if( len(a) > len(b) ) return seems like it'll work
        int cmp = dict_word[i] - test[i];
        if( cmp == 0 ) {
            printf( "%c is %c\n", dict_word[i], test[i] );
            continue;
        }
        return cmp;
    }
    return 0;
    */
}
//thank you http://saju.net.in/code/misc/openssl_aes.c.txt for the code
int decrypt_init( unsigned char *key_data, int key_data_len, unsigned char *salt, EVP_CIPHER_CTX *ctx ) {
    int i, nrounds = 1;
    unsigned char key[32], iv[16];
    i = EVP_BytesToKey( EVP_aes_256_cbc(), EVP_md5(), salt, key_data, key_data_len, nrounds, key, iv );
    if( i != 32 ) {
        fprintf( stderr, "oh noes! key too small\n" );
        return -1;
    }
    //printf( "salt=" ); print_hex( salt, 8 ); //printf("\n");
    //printf( "key =" ); print_hex( key, 32 ); //printf("\n");
    //printf( "iv  =" ); print_hex( iv, 16 ); //printf("\n");

    EVP_CIPHER_CTX_init( ctx );
    EVP_DecryptInit( ctx, EVP_aes_256_cbc(), key, iv );

    return 0;
}

unsigned char* aes_decrypt( EVP_CIPHER_CTX* ctx,
        unsigned char *ciphertext, int *len ) {
    int p_len = *len, f_len = 0;
    unsigned char *plaintext = malloc(p_len+256);

    EVP_DecryptUpdate( ctx, plaintext, &p_len, ciphertext, *len );
    EVP_DecryptFinal( ctx, plaintext+p_len, &f_len );
    *len = p_len + f_len;
    return plaintext;
}


int main( int argc, char** argv ) {
    static const char magic[] = "Salted__";
    unsigned char salt[8];
    unsigned char* ciphertext;
    int ciphertext_len, i, perm_idx, j;
    load_dict();
    FILE* infd = fopen( "message.txt.enc", "r" );
    fseek( infd, SALT_OFFSET, SEEK_CUR );
    fseek( infd, strlen( magic ), SEEK_SET );
    
    fread( salt, 1, 8, infd );
    fseek( infd, 0, SEEK_END );
    ciphertext_len = (int)ftell( infd )-strlen(magic)-PKCS5_SALT_LEN;
    ciphertext = malloc(ciphertext_len);
    fseek( infd, strlen(magic)+PKCS5_SALT_LEN, SEEK_SET );
    fread( ciphertext, 1, ciphertext_len, infd );
    fclose( infd );
    
    for( i = 0; i < dict_len; i++ ) {
        char* key_data = dict[i];
        char over[] = "school";
        
        //key_data = over;
        int key_data_len = strlen(key_data);
        perm* perms = permutations(key_data);
        
        int p = 0;
        perm_idx = 0;
        while( p == 0 ) {
            p = perm_idx;
            for( j = 0; j < perms->str_len; j++ ) {
                int base = perms->p_lens[j];
                perms->str[j] = perms->perms[j][p%base];
                p /= base;
            }
            if( strncmp( perms->str, over, 6 ) == 0 ) printf( "WHAT" );
            int check = decrypt_check( ciphertext, ciphertext_len,
                    (unsigned char *)perms->str, key_data_len, salt );
            if( check )
                printf( "check %d: %s\n", check, perms->str );
            perm_idx ++;
        }
        free( perms->p_lens );
        free( perms->perms );
        free( perms->str );
        free( perms );
    }
    
    for( i = 0; i < dict_len; i++ ) {
        free( dict[i] );
    }
    free( dict );
    //free( salt );
    free( ciphertext );
    
    return 0;
    /*
    EVP_CIPHER_CTX ctx;
    int i;
    unsigned char* ciphertext, *plaintext;
    int fd_len = 0;
    fseek( infd, 0, SEEK_END );
    fd_len = (int)ftell( infd )-strlen(magic)-PKCS5_SALT_LEN;
    ciphertext = malloc(fd_len);
    fseek( infd, strlen(magic)+PKCS5_SALT_LEN, SEEK_SET );
    fread( ciphertext, 1, fd_len, infd );
    //printf( "PKCS5_SALT_LEN: %d\n", PKCS5_SALT_LEN );
    
        
    plaintext = malloc(fd_len);

    decrypt_init( key_data, key_data_len, salt, &ctx );

    plaintext = (char*)aes_decrypt( &ctx, ciphertext, &fd_len );
    //printf( "pt %d: %s\n", fd_len, plaintext);
    print_hex( plaintext, fd_len );
    EVP_CIPHER_CTX_cleanup( &ctx );
    return 0;
    */
}
    
