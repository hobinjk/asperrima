#include "leet.h"
char* perm_table[] = {
    "a4",
    "bb",
    "c<(",
    "d",
    "e3",
    "f",
    "g",
    "h",
    "i!1",
    "j",
    "k",
    "l|1!",
    "m",
    "n",
    "o0",
    "p",
    "q",
    "r",
    "sz$",
    "t",
    "uv",
    "vu",
    "w",
    "x",
    "y",
    "zs"
};
perm* permutations( char* word ) {
    int len = strlen(word);
    perm* data = malloc(sizeof(perm));
    data->str = malloc(len+1);
    strncpy(data->str,word,len+1);
    data->str_len = len;
    data->p_lens = malloc(sizeof(int)*len);
    data->perms = malloc(sizeof(char*)*len);
    
    int chr_idx, per_idx;
    for( chr_idx = 0; chr_idx < len; chr_idx++ ) {
        char chr = word[chr_idx];
        data->perms[chr_idx] = perm_table[chr-97];
        data->p_lens[chr_idx] = strlen( perm_table[chr-97] );
    }
    return data;
}

/*

int main( int argc, char** argv ) {
    char* word = argv[1];
    char* tmp = malloc(strlen(word)+1);
    tmp[strlen(word)] = '\0';
    perm* data = permutations( word );
    int len, i, j, k;
    len = strlen( word );

    int idx = 0;
    while( 1 ) {
        i = idx;
        for( j = 0; j < data->str_len; j++ ) {
            int base = data->p_lens[j];
            tmp[j] = data->perms[j][i%base];
            i /= base;
        }
        printf( "%s\n", tmp );
        if( i > 0 ) break;
        idx ++;
    }
    return 0;
}
*/

