#ifndef _LEET_H
#define _LEET_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct perm_ {
    char* str;
    char** perms; //this should work better, see below
    int* p_lens;
    int str_len;
} perm;


perm* permutations( char* word );
#endif
