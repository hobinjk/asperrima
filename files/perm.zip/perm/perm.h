#ifndef PERM_H
#define PERM_H
#include <stdlib.h>
#include <stdio.h>
#include <openssl/evp.h>
#include <string.h>
#include "leet.h"
#define SALT_OFFSET (10)

unsigned char* aes_decrypt(
        EVP_CIPHER_CTX* ctx,
        unsigned char *ciphertext,
        int *len );
int streq( char* a, char* b, int len  );
void load_dict();
void print_hex( unsigned char* dat, int dat_len );
int decrypt_check( unsigned char* ciphertext, int ciphertext_len,
        unsigned char *key_data, int key_data_len, unsigned char *salt );
float words( char* text, int len );
int word( char* test, int start, int end );
int streq( char* dict, char* test, int test_len  );
int decrypt_init( unsigned char *key_data, int key_data_len,
        unsigned char *salt, EVP_CIPHER_CTX *ctx );

#endif
