package jkh.smallab;

import java.io.File;
import java.util.ArrayList;

import jk.naturalpoint.Wand;
import processing.core.PApplet;

public class StrokeOrderGame {
	ArrayList<StrokeTarget> targets = new ArrayList<StrokeTarget>();
	ArrayList<File> files = new ArrayList<File>();
	StrokeOrder p;
	
	int strokeCount;
	int strokeIndex;
	CharacterDraw charDraw;
	StrokeTarget current;
	State state = State.WAIT_RESTART;
	Wand wand;
	int wandDiam = 30;
	int errors = 0;
	int avatarColor;
	public int score;
	
	float lastError = -9001*9001;
	float errorLength = 2000;
	int maxErrors = 3;
	private boolean helping = false;
	public int clr;
	private boolean cleared;
	
	public StrokeOrderGame( StrokeOrder p_, int clr_ ) {
		p = p_;
		wand = new Wand();
		clr = clr_;
	}
	private void setAvatarColor() {
		avatarColor = p.color( strokeIndex*360/strokeCount, 255, 255 );
	}
	void drawAvatar() {
		if( helping && cleared ) {
			helpDraw();
			cleared = false;
		} 
		
		p.fill(avatarColor);
		p.stroke(avatarColor);

		p.ellipse(wand.x, wand.y, wandDiam, wandDiam);
		
	}
	private void helpDraw() {
		p.textAlign( PApplet.CENTER, PApplet.CENTER );
		p.textFont( p.smallFont );
		p.ellipseMode( PApplet.CENTER) ;
		for( int i = 0; i < targets.size(); i++ ) {
			StrokeTarget st = targets.get(i);
			
			float h, a;
			h = i*360/targets.size();
			a = (i == strokeIndex) ? 255: 60;
			p.fill(h,255,255,a);
			p.stroke(h,255,255,a);
			p.ellipse(st.startX, st.startY, st.diam, st.diam);
			p.ellipse(st.endX, st.endY, st.diam, st.diam);
		}
		for( int i = 0; i < targets.size(); i++ ) {
			StrokeTarget st = targets.get(i);
			float a = (i == strokeIndex) ? 255: 60;
			p.fill(0,0,0,a);
			p.stroke(0,0,0,a);
			p.text((i+1)+"\nstart", st.startX, st.startY);
			p.text((i+1)+"\nend", st.endX, st.endY);
		}
	}
	private void clear() {
		p.fill(0);
		p.stroke(0);
		p.rect(0, 0, p.width, p.height);
		cleared = true;
	}
	private void startingDraw() {
		clear();
	
		charDraw.draw();

		drawAvatar();
		for( int i = strokeIndex; i < targets.size(); i++ ) {
			StrokeTarget sot = targets.get(i);
			float dist = (sot.startX - wand.x)*(sot.startX - wand.x)
					+ (sot.startY - wand.y)*(sot.startY - wand.y);
			
			if( dist > wandDiam*wandDiam/4 + sot.diam*sot.diam/4 ) continue;
			
			current = sot;
			if( i != strokeIndex ) {
				if( lastError + errorLength > p.millis() ) continue;
				if( dist > wandDiam*wandDiam/8 + sot.diam*sot.diam/8 ) continue;
				errors++;
				current = null;
				p.bonk.trigger();
				System.out.println("oops!");
				if( errors >= maxErrors )
					state = State.LOSE;
				else
					state = State.FAILURE;
				lastError = p.millis();
				
				return;
			}
			p.yay.trigger();
			
			state = State.FOLLOWING;
			return;
		}
	}
	
	private void followingDraw() {
		drawAvatar();

		for( int i = strokeIndex; i < targets.size(); i++ ) {
			StrokeTarget sot = targets.get(i);
			float dist = (sot.endX - wand.x)*(sot.endX - wand.x)
					+ (sot.endY - wand.y)*(sot.endY - wand.y);
			
			if( dist > (wandDiam/2*wandDiam/2) + (sot.diam/2)*(sot.diam/2) ) continue;
			if( i != strokeIndex ) {
				if( lastError + errorLength > p.millis() ) continue;
				if( dist > wandDiam*wandDiam/8 + sot.diam*sot.diam/8 ) continue;
				errors++; //heh heheheheheheh yes
				p.bonk.trigger();
				if( errors >= maxErrors )
					state = State.LOSE;
				else
					state = State.FOLLOWING;
				lastError = p.millis();
				return;
			}
			p.yay2.trigger();
			//charDraw.set()
			state = State.SUCCESS;
			return;
		}
	}



	private void successDraw() {
		
		//charDraw.set(this.get()); //haaax
		//targets.remove(0);
		strokeIndex++;
		setAvatarColor();
		
		if( strokeIndex == strokeCount ) {
			state = State.WIN;
		} else {
			state = State.STARTING;
		}
	}

	private void failureDraw() {
		state = State.STARTING;//EH
	}

	private void winDraw() {
		clear();
		p.textFont( p.largeFont );
		p.winning.trigger();
		p.fill( clr );
		p.stroke( clr );
		p.textAlign( PApplet.CENTER, PApplet.CENTER );
		p.text( "Complete!", p.width/2, p.height/2 );
		state = State.WAIT_RESTART;
	}

	private void loseDraw() {
		p.failure.trigger();
		
		clear();
		p.textFont( p.largeFont );
		p.fill( clr );
		p.stroke( clr );
		
		p.textAlign( PApplet.CENTER, PApplet.CENTER );
		p.text( "Failure", p.width/2, p.height/2 );
		state = State.WAIT_RESTART;
	}
	
	public void restartDraw() {
		errors = 0;
		strokeIndex = 0;
		state = State.STARTING;
		
	}
	public void draw() {
		//frame.setLocation(screenWidth+screenWidth/2-width, screenHeight+screenHeight/2-height);
		//System.out.println(green.x+","+green.y+","+green.z);
		
		//System.out.println(state);
		switch( state ) {
		case STARTING:
			startingDraw();
			break;
		case FOLLOWING:
			followingDraw();
			break;
		case SUCCESS:
			successDraw();
			break;
		case WIN:
			winDraw();
			break;
		case LOSE:
			loseDraw();
			break;
		case FAILURE:
			failureDraw();
			break;
		}
	}

	
	public void updateWand(float x, float y, float rawZ) {
		wand.x = x;
		wand.y = y;
		wand.rawZ = rawZ;
	}
	public void toggleHelping() {
		helping = !helping;
	}
	public void setInformation(ArrayList<StrokeTarget> targets_,
			CharacterDraw charDraw_) {
		targets = targets_;
		
		charDraw= charDraw_;
		//description = description_;
		strokeCount=targets.size();
		setAvatarColor();
	}
	
	
	
}
