package jkh.smallab;

import processing.core.PApplet;

public class StrokeTarget {
	float startX, startY;
	float endX, endY;
	float nStartX, nStartY;
	float nEndY, nEndX;
	int diam = 75;
	public StrokeTarget( PApplet parent, float nStartX2, float nStartY2, float nEndX2, float nEndY2) {
		nStartX = nStartX2;
		nStartY = nStartY2;
		nEndX = nEndX2;
		nEndY = nEndY2;
		
		startX = (nStartX2+0.5f)*parent.height;
		startY = (nStartY2+0.5f)*parent.height;
		endX = (nEndX2+0.5f)*parent.height;
		endY = (nEndY2+0.5f)*parent.height;
	}
	public StrokeTarget( float startX2, float startY2, float endX2, float endY2) {
		nStartX = startX2;
		nStartY = startY2;
		nEndX = endX2;
		nEndY = endY2;
	}
	
	
	public StrokeTarget(PApplet parent, String base) {
		String[] comps = base.split("[:,]");
		nStartX = Float.parseFloat( comps[0] );
		nStartY = Float.parseFloat( comps[1] );
		nEndX = Float.parseFloat( comps[2] );
		nEndY = Float.parseFloat( comps[3] );
		if( parent != null ) {
			startX = (nStartX+0.5f)*parent.height;
			startY = (nStartY+0.5f)*parent.height;
			endX = (nEndX+0.5f)*parent.height;
			endY = (nEndY+0.5f)*parent.height;
		}
	}
	
	@Override
	public String toString() {
		return String.format("%f,%f:%f,%f", nStartX, nStartY, nEndX, nEndY);
	}
	
}
