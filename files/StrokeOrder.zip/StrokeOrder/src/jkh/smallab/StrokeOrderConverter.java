package jkh.smallab;

import java.io.File;

import processing.core.PApplet;

public class StrokeOrderConverter extends PApplet {
	private static final long serialVersionUID = 1L;
	public static void main( String[] args ) {
		PApplet.main( new String[] { StrokeOrderConverter.class.toString().split(" ")[1] } );
	}
	public void setup() {
		File[] fileList = new File("./").listFiles();
		size(800, 800);
		
		for( File f : fileList ) {
			//System.out.println(f.getName());
			if( f.isDirectory() ) continue;
			if( f.getName().indexOf(".gest") == -1 ) continue;
			System.out.println("converting");
			//convert( f );
			int codePoint = Integer.parseInt( f.getName().split("_")[0] );
			char[] test = Character.toChars(codePoint);
			CharacterDraw charDraw = new CharacterDraw( this, test[0], "" );
			charDraw.draw();
			//charDraw.character.save(f.getName()+".png");
		}
	}
	public void draw() {
		exit();
	}
//	
//	private static void convert( File file ) {
//		BufferedReader reader = null;
//		try {
//			reader = new BufferedReader( new FileReader( file ) );
//		} catch (FileNotFoundException e2) {
//			e2.printStackTrace();
//		}
//		BufferedWriter converted = null;
//		try {
//			converted = new BufferedWriter( new FileWriter( file.getName()+".conv" ) );
//		} catch (IOException e2) {
//			e2.printStackTrace();
//		} 
//		String line = "";
//		try {
//			while( (line = reader.readLine()) != null ) {
//				StrokeTarget st = new StrokeTarget( null, line );
//				st.nStartX /= 800;
//				st.nStartY /= 800;
//				st.nEndX /= 800;
//				st.nEndY /= 800;
//				System.out.println("writing: "+st.toString());
//				converted.write(st.toString());
//				converted.newLine();
//			}
//		} catch (IOException e1) {
//			e1.printStackTrace();
//		}
//		try {
//			reader.close();
//			converted.close();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
}
