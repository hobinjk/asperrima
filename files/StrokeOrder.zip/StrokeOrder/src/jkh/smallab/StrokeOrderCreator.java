package jkh.smallab;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PVector;

@SuppressWarnings("serial")
public class StrokeOrderCreator extends PApplet {
	CharacterDraw charDraw;
	ArrayList<PVector> targets = new ArrayList<PVector>();
	String charList = "岁";//"月号星期天生日今年多大岁吃饭怎么样太了谢喜欢菜还是可我们点半晚上见再";//"犬火水天六五曰夕口子女大三人刀十匕二一右左北包禾目四玎叫去可本他白";
	String inBuf = "";
	String DIR = "lesson3/";
	
	public static void main( String[] args ) {
		PApplet.main( new String[] { "jkh.smallab.StrokeOrderCreator" } );
	}
	public void setup() {
		size(screenHeight,screenHeight);
		startNext();
		//charDraw = new CharacterDraw( this, '一', "" );
		textFont( createFont( "Times New Roman", 40 ) );
		textAlign( CENTER, CENTER );
	}
	void startNext() {
		charDraw=  new CharacterDraw( this, charList.charAt(0), "" );
		charList = charList.substring(1);
		targets.clear();
		inBuf = "";
		readInfo();
	}
	public void draw() {
		background(0);
		charDraw.draw();
		stroke(0,0,255);
		fill(0,0,255);
		for( PVector vec: targets ) {
			ellipse(vec.x,vec.y,10,10);
		}
		fill(255);
		stroke(255);
		text(inBuf,width/2,height-100);
		
		
	}
	
	private void write() {
		BufferedWriter boss = null;
		try {
			File file = new File(DIR+charDraw.unicodeRep()+"_strokes.gest");
			System.out.println(file.getAbsolutePath());
			boss = new BufferedWriter( new FileWriter( file ) );
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
		System.out.println("writing "+(targets.size()/2)+" thing(s)");
		try {
			boss.write(inBuf+"\n");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		for( int i = 0; i < targets.size()/2; i++ ) {
			float startX = ((float)(targets.get(i*2).x-screenHeight/2))/screenHeight;
			float startY = ((float)(targets.get(i*2).y-screenHeight/2))/screenHeight;
			float endX = ((float)(targets.get(i*2+1).x-screenHeight/2))/screenHeight;
			float endY = ((float)(targets.get(i*2+1).y-screenHeight/2))/screenHeight;
			StrokeTarget st  = new StrokeTarget(startX, startY, endX, endY);
			System.out.println("writing "+st);
			try {
				boss.write(st.toString());
				boss.newLine();
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
			
		}
		try {
			boss.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		startNext();
	}
	public void readInfo() {
		try {
			BufferedReader br = new BufferedReader( new FileReader( DIR+charDraw.unicodeRep()+"_strokes.gest" ) );
			try {
				String startInfo = br.readLine();
				inBuf = startInfo.trim();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	public void mousePressed() {
		targets.add( new PVector( mouseX, mouseY ) );
	}
	public void keyPressed() {
		if( keyCode == DELETE ) {
			if( targets.size() > 0 ) targets.remove(targets.size()-1);
			return;
		}
		if( keyCode == LEFT ) {
			inBuf = "";
			return;
		}
		
		if( keyCode == ENTER ) {
			write();
			return;
		}
		if( key != CODED )
		inBuf += key;
	}
}
