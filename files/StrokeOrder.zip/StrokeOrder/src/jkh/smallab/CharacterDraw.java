package jkh.smallab;

import processing.core.PApplet;
import processing.core.PFont;

public class CharacterDraw {
	char chinese;
	PApplet p;
	String desc;
	PFont big, small;

	public CharacterDraw( PApplet p_, char chinese_, String description ) {
		this( p_, chinese_, description, null, null );
	}
	public CharacterDraw( PApplet p_, char chinese_, String description, PFont big_, PFont small_ ) {
		p = p_;
		chinese = chinese_;
		big = big_;
		small = small_;
		if( big == null || small == null )
			throw new RuntimeException( "we aren't standing for that anymore ");
		/*
		if( big == null ) {
 			char[] charset = new char[] { chinese };
 			big = p.createFont( "Times New Roman", (int)(p.height*0.7), true, charset );
 		}
 		if( small == null ) small = p.createFont( "Times New Roman", 24 );
 		*/
 		//character.text( description, p.width/2, p.height-100 );
	}
	
	public void draw() {
		p.fill(255);
 		p.stroke(255);
 		p.textAlign( PApplet.CENTER, PApplet.CENTER );
 		p.textFont( big );
 		p.text( chinese+"", p.width/2, p.height/2 );
 		//p.textFont(small );
	}
	public int unicodeRep() {
		return Character.codePointAt( new char[] {chinese}, 0 );
	}
}
