package jkh.smallab;

public enum State {
	STARTING, FOLLOWING, SUCCESS, FAILURE, WIN, LOSE, RESTART, WAIT_RESTART
}
