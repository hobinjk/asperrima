package jkh.smallab;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import jk.naturalpoint.SMALLab;
import jk.naturalpoint.Wand;
import processing.core.PApplet;
import processing.core.PFont;
import ddf.minim.AudioSample;
import ddf.minim.Minim;

public class StrokeOrder extends PApplet {
	private static final long serialVersionUID = 1L;
	StrokeOrderGame left, right;
	private SMALLab lab;
	private Wand green, orange;
	private Minim minim;
	public PFont largeFont;
	public PFont smallFont, mediumFont;
	public AudioSample bonk, yay, yay2, winning, failure;
	public PFont chineseFont;
	private ArrayList<File> files = new ArrayList<File>();
	private boolean scored;
	private CharacterDraw charDraw;
	
	
	ArrayList<StrokeTarget> targets;
	private String description;
	private int counter = 1000/60;;
	private static final boolean labbing = false;
	
	public void setup() {
		size(screenHeight,screenHeight);
		colorMode( HSB, 360, 255, 255 );
		smooth();
		lab = new SMALLab(this);
		lab.start();
		
		smallFont = createFont( "Times New Roman", 20, true );
		mediumFont = createFont( "Times New Roman", 50, true );
		largeFont = createFont( "Times New Roman", 100, true );
		
		findGestureFiles();
		
		minim = new Minim( this );
		bonk = minim.loadSample("bonk.wav");
		yay = minim.loadSample("yay.wav");
		yay2 = minim.loadSample("yay2.wav");
		winning = minim.loadSample("winning.mp3");
		failure = minim.loadSample("failure.mp3");
		
		left = new StrokeOrderGame(this, 0xff00ff00);
		right = new StrokeOrderGame(this,0xffff8000);
		green = lab.green;
		orange = lab.orange;
		
	}
	public void draw() {
		if( left.state == State.RESTART && right.state == State.RESTART ) {
			findTarget();
		}
		fill(0);
		stroke(0);
		rect(0,0,width,height/4);
		rect(0,width*3/4,width,height/4);
		textFont(largeFont);
		textAlign( CENTER, CENTER );
		fill(left.clr);
		text(""+left.score,width/4,height/8);
		fill(right.clr);
		text(""+right.score,width*3/4,height/8);
		fill(0xffffffff);
		if( description != null ) {
			textFont(mediumFont);
			text(description.replaceAll(":", " - "), width/2, height*7/8);
		}
		translate(0,height/4);
		pushMatrix();
		translate(0,0);
		scale(0.5f);
		if( labbing ) {
			left.updateWand( green.x*2, green.y*2, green.rawZ );
			right.updateWand( (orange.x-width/2)*2, (orange.y-height/2)*2, orange.rawZ );
		} else { 
			left.updateWand( mouseX, mouseY, 0 );
			right.updateWand( width-mouseX, height-mouseY, 0);
		}
		left.draw();
		popMatrix();
		pushMatrix();
		translate(width/2,0);
		scale(0.5f);
		right.draw();
		popMatrix();
		
		if( left.state == State.WIN && !scored ) {
			left.score ++;
			scored = true;
		} else if( right.state == State.WIN && !scored ) {
			right.score ++;
			scored = true;
		
		//} else if( (left.state == State.LOSE) && (right.state == State.LOSE)) {
		}
		
		if( (right.state == State.WAIT_RESTART || left.state == State.WAIT_RESTART) && scored ) {
			counter--;
			if( counter < 0 ) restart();
		}
		if( right.state == State.WAIT_RESTART && left.state == State.WAIT_RESTART ) {
			counter--;
			if( counter < 0 ) restart();
		}
		//System.out.println("r: "+right.state+" l: "+left.state);
	}
	void restart() {
		findTarget();
		right.restartDraw();
		left.restartDraw();
		counter = 1000/10;
		scored = false;
	}
	private void findGestureFiles() {
		File[] fileList = new File("./lesson3").listFiles();
		for( File f : fileList ) {
			if( f.isDirectory() ) continue;
			if( f.getName().indexOf("strokes.gest") == -1) continue;
			int codePoint = Integer.parseInt( f.getName().split("_")[0] );
			char[] test = Character.toChars(codePoint);
			System.out.println(codePoint+" "+test[0]);
			//System.out.println("必");
			files.add( f );
		}
		char[] charset = new char[files.size()];
		int i = 0;
		for( File f : files ) {
			int codePoint = Integer.parseInt( f.getName().split("_")[0] );
			char[] test = Character.toChars(codePoint);
			charset[i++] = test[0];
		}
		if( chineseFont == null )
			chineseFont = createFont( "Times New Roman", (int)(height*0.7), true, charset );
	}
	void findTarget() {
		if( files.size() == 0 )
			findGestureFiles();
		
		Random gen = new Random();
		
		int idx = gen.nextInt(files.size());
		
		readStrokes( files.get(idx) );
		left.setInformation( targets, charDraw );
		right.setInformation( targets, charDraw );
		files.remove(idx);
		
	}
	public static void main( String[] args ) {
		System.out.println( StrokeOrder.class.toString() );
		PApplet.main( new String[] { StrokeOrder.class.toString().split(" ")[1] } );
	}
	public void readStrokes( File f ) {
		int codePoint = Integer.parseInt( f.getName().split("_")[0] );
		char[] test = Character.toChars(codePoint);
		//System.out.println(codePoint+" "+test[0]);
		if( test.length > 1 ) System.out.println("oopsydaisy");
		readFile( f );
		charDraw = new CharacterDraw( this, test[0], description, chineseFont, smallFont );
		
	}
	private void readFile( File f ) {
		BufferedReader reader = null;
		System.out.println(f.getName());
		targets = new ArrayList<StrokeTarget>();
		try {
			reader = new BufferedReader( new FileReader( f ) );
			String line = "";
			description = reader.readLine();
			
			while( (line = reader.readLine()) != null ) {
				StrokeTarget st = new StrokeTarget( this, line );
				System.out.println(st);
				targets.add( st );
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
	public void keyPressed() {
		switch( key ) {
		case 'h':
			left.toggleHelping();
			right.toggleHelping();
			break;
		case 'n':
			restart();
			break;
		case 'r':
			left.score = 0;
			right.score = 0;
			break;
		}
	}
	
	
	
	
	
}
