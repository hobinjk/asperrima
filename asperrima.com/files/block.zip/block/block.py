allwords = []
letters = raw_input("letters: ")

dictfile = open('wordlist.txt', 'r')
for word in dictfile:
    cur_lets = list(letters)
    found = True
    word = word.rstrip()
    for letter in word:
        if letter not in cur_lets:
            found = False
            break
        idx = cur_lets.index(letter)
        del cur_lets[idx]
    if found:
        allwords.append(word)
print( allwords )

