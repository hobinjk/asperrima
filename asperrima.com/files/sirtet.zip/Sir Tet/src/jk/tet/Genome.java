package jk.tet;

import java.util.Random;

public class Genome {
	private Piece[] pieces = new Piece[5];
	private static Random gen = new Random();
	private Field field;
	int score;
	
	public Genome(Piece[] workingPieces) {
		for( int i = 0; i < pieces.length; i++ ) {
			Piece wp = workingPieces[i];
			determineRandom( wp, i );
		}
	}
	
	private void determineRandom( Piece workingPiece, int idx ) {
		Piece piece = null;
		while( true ) {
			int col = gen.nextInt(20);
			int rot = gen.nextInt(4);
			
			piece = new Piece( field, workingPiece, col, rot );
			if(!field.isPieceInsertableIn(piece) ) continue;
			break;
		}
		pieces[idx] = piece;
		
		score += field.checkHoles();
		
	}
	
}
