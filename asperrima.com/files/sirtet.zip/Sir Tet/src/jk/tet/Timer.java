package jk.tet;

class Timer {
	static long startMillis;
	
	static void start() {
		startMillis = System.currentTimeMillis(); 
	}
	static void end( String tag ) {
		System.out.println(tag+" took "+(System.currentTimeMillis()-startMillis)+" ms");
	}
}