package jk.tet;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;



public class GameInfoFinder {
	private int gameX, gameY;
	private BufferedImage holdImage;
	private BufferedImage iImage, jImage, lImage, oImage, sImage, tImage, zImage;
	private BufferedImage iNextImage, jNextImage, lNextImage;
	private BufferedImage oNextImage, sNextImage, tNextImage, zNextImage;
	
	private int startX = 4;
	private Robot robot;
	private static final char[] types = new char[] { 't', 's', 'z', 'l', 'j', 'i', 'o' };
	private final Random gen = new Random();
	private boolean testing = false;
	
	public GameInfoFinder( Robot robot_ ) {
		try {
			holdImage = ImageIO.read(new File("data/hold.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		robot = robot_;
		try {
			iImage = ImageIO.read(new File("data/i.png"));
			jImage = ImageIO.read(new File("data/j.png"));
			lImage = ImageIO.read(new File("data/l.png"));
			oImage = ImageIO.read(new File("data/o.png"));
			sImage = ImageIO.read(new File("data/s.png"));
			tImage = ImageIO.read(new File("data/t.png"));
			zImage = ImageIO.read(new File("data/z.png"));
			
			iNextImage = ImageIO.read(new File("data/iNext.png"));
			jNextImage = ImageIO.read(new File("data/jNext.png"));
			lNextImage = ImageIO.read(new File("data/lNext.png"));
			oNextImage = ImageIO.read(new File("data/oNext.png"));
			sNextImage = ImageIO.read(new File("data/sNext.png"));
			tNextImage = ImageIO.read(new File("data/tNext.png"));
			zNextImage = ImageIO.read(new File("data/zNext.png"));
			

			//displayImage( jNextImage );
			//displayImage( lNextImage );
			
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public Field findField( Field current ) {
		return findFieldLimit( 2 );
		
		
	}
	private char typeFromHue( float hue ) {
		hue *= 360;
		//types = new char[] { 't', 's', 'z', 'l', 'j', 'i', 'o' };
		float[] diffs = new float[types.length]; 
		diffs[0] = Math.abs(hue - 312); ; //'t'
		
		diffs[1] = Math.abs(hue - 85); //'s'
		
		diffs[2] = Math.abs(hue - 350); //'z'
		diffs[2] = diffs[2] < hue ? diffs[1] : hue;
		
		diffs[3] = Math.abs(hue - 15); //l
		
		diffs[4] = Math.abs(hue - 226); //j
		
		diffs[5] = Math.abs(hue - 180); //i
		
		diffs[6] = Math.abs(hue - 37);
		
		float least = Float.MAX_VALUE;
		char leastT = ' ';
		for( int i = 0; i < diffs.length; i++ ) { 
			if( diffs[i] > least ) continue;
			least = diffs[i];
			leastT = types[i];
		}
		return leastT;	
	}
	public boolean findGame() {
		if( testing ) {
			gameX = 0;
			gameY = 0;
			System.out.println("Testing coords located");
			return true;
		}
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		
		int[] coords = find( holdImage, screenCap( 0,0, screen.width, screen.height ));
		if( coords == null ) {
			System.out.println("not found");
			return false;
		}
		
		gameX = coords[0];
		gameY = coords[1];
		System.out.println("Coords located");
		return true;
	}
	
	public Piece findCurrentPiece( ) {
		if( testing )
			return new Piece( null, types[gen.nextInt(types.length)], 4, 0 );
		BufferedImage capture = screenCap( gameX+100, gameY , 200, 200 );
		return pieceFromImage( capture );
	}
	public Piece findNextPiece( ) {
		if( testing )
			return new Piece( null, types[gen.nextInt(types.length)], 4, 0 );
		
		BufferedImage capture = screenCap( gameX+290, gameY+40, 100, 90 );
		//displayImage( capture );
		return pieceFromNextImage( capture );
		
	}
	private Piece pieceFromImage( BufferedImage capture ) {
		char type = ' ';
		if( exists( iImage, capture ) ) 
			type = 'i';
		else if( exists( jImage, capture ) )
			type = 'j';
		else if( exists( lImage, capture ) )
			type = 'l';
		else if( exists( oImage, capture ) )
			type = 'o';
		else if( exists( sImage, capture ) )
			type = 's';
		else if( exists( zImage, capture ) )
			type = 'z';
		else if( exists( tImage, capture ) )
			type = 't';
		else {
			System.err.println("didn't find anything");
			return null;
		}
		
		return new Piece( null, type, startX, 0 );
	}
	Piece pieceFromNextImage( BufferedImage capture ) {
		char type = ' ';
		if( exists( iNextImage, capture ) ) 
			type = 'i';
		else if( exists( jNextImage, capture ) )
			type = 'j';
		else if( exists( lNextImage, capture ) )
			type = 'l';
		else if( exists( oNextImage, capture ) )
			type = 'o';
		else if( exists( sNextImage, capture ) )
			type = 's';
		else if( exists( zNextImage, capture ) )
			type = 'z';
		else if( exists( tNextImage, capture ) )
			type = 't';
		else {
			System.err.println("didn't find anything");
			return null;
		}
		
		return new Piece( null, type, startX, 0 );
	}
	
	private boolean exists( BufferedImage template, BufferedImage cap) {
		return find( template, cap ) != null;
	}
	private int[] find( BufferedImage templateIcky, BufferedImage capIcky ) {
		BufferedImage template = new BufferedImage( templateIcky.getWidth(), templateIcky.getHeight(), BufferedImage.TYPE_INT_RGB );
		BufferedImage cap = new BufferedImage( capIcky.getWidth(), capIcky.getHeight(), BufferedImage.TYPE_INT_RGB );
		template.getGraphics().drawImage(templateIcky, 0, 0, null);
		cap.getGraphics().drawImage(capIcky, 0, 0, null);
		
		for( int x = 0; x < cap.getWidth()-template.getWidth()+1; x++ ) {
			for( int y = 0; y < cap.getHeight()-template.getHeight()+1; y++ ) {
				boolean good = true;
				for( int tx = 0; tx < template.getWidth() && good; tx++ ) {
					for( int ty = 0; ty < template.getHeight() && good; ty++ ) {
						int tplRGB = template.getRGB( tx, ty );
						int capRGB = cap.getRGB( x+tx, y+ty );
						
						if( Math.abs(blue(tplRGB) - blue(capRGB)) > 50 ) {
							good = false;
							break;
						}
						if( Math.abs(red(tplRGB) - red(capRGB)) > 50 ) {
							good = false;
							break;
						}
						if( Math.abs(green(tplRGB) - green(capRGB)) > 50 ) {
							good = false;
							break;
						}
						//displayImage( cap.getSubimage( x, y, template.getWidth(), template.getHeight() ));
						
						
						
					}
				}
				if( good ) return new int[] { x, y };
			}
		}
		return null;
	}
	
	public int blue( int rgb ) {
		return rgb & 0xff;
	}
	public int red( int rgb ) {
		return ( rgb >> 16 ) & 0xff;
	}
	public int green( int rgb ) {
		return ( rgb >> 8 ) & 0xff;
	}
	/*
	public int brightness( int rgb ) {
		//thank you processing
		float[] val = new float[3];
		Color.RGBtoHSB((rgb >> 16) & 0xff, (rgb >> 8) & 0xff,
                rgb & 0xff, val);
		System.out.println(val[2]);
		return (int)(val[2]*255);
	}
	*/
	BufferedImage screenCap( int x, int y, int w, int h ) {
		Rectangle captureRegion = new Rectangle( new Point( x, y ), new Dimension( w, h ) );
		BufferedImage bi = robot.createScreenCapture(captureRegion);
		return bi;
		
	}
	private BufferedImage scaleImage(BufferedImage image, int width, int height ) {
		BufferedImage small = new BufferedImage( width, height, BufferedImage.TYPE_INT_RGB );
		small.getGraphics().drawImage( image, 0, 0, width, height, null );
		
		return small;
	}

	public int findLeftMostPieceColumn() {
			
		BufferedImage capture = screenCap( gameX+106, gameY+25, 180, 360 );
		BufferedImage small = scaleImage( capture, 10, 20 );
		
		int retCol = 100;
		boolean foundAny = false;
		
		for( int line = small.getHeight() - 1; line > -1; line-- ) { //yearp
			boolean foundThisLine = false;
			for( int col = 0; col < small.getWidth(); col++ ) {
				int rgb = small.getRGB( col,small.getHeight()-line-1 );
				float[] hsb = new float[3];
				Color.RGBtoHSB( red(rgb), green(rgb), blue(rgb), hsb );
				
				if( hsb[2]*255 < 50 )
					continue;
				if( col < retCol )
					retCol = col;
				
				foundThisLine = true;
				foundAny = true;
			}
			if(!foundThisLine && foundAny ) break;
		}
		return retCol;
	}

	public Field findFieldLimit(int limit) {
		Field field = new Field(20,10);
		
		//Timer.start();
		BufferedImage capture = screenCap( gameX+106, gameY+25, 180, 360 );
		//Timer.end("capture");
		//Timer.start();
		BufferedImage small = scaleImage( capture, field.getColumns(), field.getLines() );
		//Timer.end("scale");
		field.clear();
		for( int line = 0; line < field.getLines()-limit; line++ ) { //yearp
			for( int col = 0; col < field.getColumns(); col++ ) {
				int rgb = small.getRGB( col, field.getLines()-line-1 );
				float[] hsb = new float[3];
				Color.RGBtoHSB( red(rgb), green(rgb), blue(rgb), hsb );
				
				if( hsb[2]*255 < 127 ) continue;
				char t = typeFromHue( hsb[0] );
				//System.out.println(hsb[0]*360);
				small.setRGB( col, field.getLines()-line-1, 0xffffffff );
				field.putBlock( line, col, new Tuple(0,0), t );
			}
		}
		
		//displayImage( small );
		
		return field;
	}
	
	public Piece findFallingPiece() {
		Field field = findFieldLimit(0);
		return field.findFallingPiece();
	}
	
}
