package jk.tet;


public class Piece {
	Field field;
	Tuple[][] pieces; //uses preentered slick stuff from path to glory tutorial
	int rotation;
	int line, column;
	public float score;
	public int scoreLines, scoreHoles, scorePeshul, scoreGaps;
	
	char type;
	public boolean valid = true;
	public int rotations;

	public void hardDrop() {
		line = field.getLines()-6;
		if( !field.isPieceInsertableIn( this ) ) {
			valid = false;
			return;
		}
		while( field.isPieceInsertableIn( this ) )
			line--;
		line++;
		place();

		scoreHoles = field.checkHoles(); 
		scoreLines = field.checkDestroyedLines();
		scoreGaps = field.checkGaps();
		scorePeshul = 0;
		for( int i = 0; i < 4; i++ ) {
			scorePeshul += (line+getPosOfBlock(i).y)/4.0f;
		}
		
		score = scorePeshul/3.0f - scoreLines*scoreLines*4 + scoreHoles;// + scoreGaps/3.0f;
		
	}

	private static final Tuple[][] TRotationMatrix = {
		{new Tuple(0,0), new Tuple(-1,0), new Tuple(1,0), new Tuple(0,1)},
		{new Tuple(0,0), new Tuple(0,1), new Tuple(0,-1), new Tuple(1,0)},
		{new Tuple(0,0), new Tuple(1,0), new Tuple(-1,0), new Tuple(0,-1)},
		{new Tuple(0,0), new Tuple(0,-1), new Tuple(0,1), new Tuple(-1,0)}
	};
	private static final Tuple[][] SRotationMatrix = {
		{new Tuple(0,0), new Tuple(1,0), new Tuple(0,-1), new Tuple(-1,-1)},
		{new Tuple(0,0), new Tuple(0,1), new Tuple(1,0), new Tuple(1,-1)},
		//{new Tuple(0,0), new Tuple(1,0), new Tuple(0,-1), new Tuple(-1,-1)},
		//{new Tuple(-1,0), new Tuple(-1,1), new Tuple(0,0), new Tuple(0,-1)}
	};
	private static final Tuple [][] ZRotationMatrix = {
		{new Tuple(0,0), new Tuple(-1,0), new Tuple(0,-1), new Tuple(1,-1)},
		{new Tuple(1,0), new Tuple(1,1), new Tuple(0,0), new Tuple(0,-1)},
		//{new Tuple(0,0), new Tuple(-1,0), new Tuple(0,-1), new Tuple(1,-1)},
		//{new Tuple(0,0), new Tuple(0,1), new Tuple(-1,0), new Tuple(-1,-1)}
	};
	private static final Tuple [][] ORotationMatrix = {
		{new Tuple(0,0), new Tuple(1,0), new Tuple(0,-1), new Tuple(1,-1)},
		//{new Tuple(0,0), new Tuple(1,0), new Tuple(0,-1), new Tuple(1,-1)},
		//{new Tuple(0,0), new Tuple(1,0), new Tuple(0,-1), new Tuple(1,-1)},
		//{new Tuple(0,0), new Tuple(1,0), new Tuple(0,-1), new Tuple(1,-1)}
	};
	private static final Tuple [][] IRotationMatrix = {
		{new Tuple(0,0), new Tuple(-1,0), new Tuple(1,0), new Tuple(2,0)},
		{new Tuple(0,0), new Tuple(0,1), new Tuple(0,-1), new Tuple(0,-2)},
		{new Tuple(0,0), new Tuple(-1,0), new Tuple(1,0), new Tuple(2,0)},
		{new Tuple(0,0), new Tuple(0,-1), new Tuple(0,1), new Tuple(0,2)}
	};
	private static final Tuple [][] LRotationMatrix = {
		{new Tuple(0,0), new Tuple(1,0), new Tuple(-1,0), new Tuple(1,1)},
		{new Tuple(0,0), new Tuple(0,-1), new Tuple(0,1), new Tuple(1,-1)},
		{new Tuple(0,0), new Tuple(-1,0), new Tuple(1,0), new Tuple(-1,-1)},
		{new Tuple(0,0), new Tuple(0,1), new Tuple(0,-1), new Tuple(-1,1)}
	};

	private static final Tuple [][] JRotationMatrix = {
		{new Tuple(0,0), new Tuple(-1,0), new Tuple(1,0), new Tuple(-1,1)},
		{new Tuple(0,0), new Tuple(0,-1), new Tuple(0,1), new Tuple(1,1)},
		{new Tuple(0,0), new Tuple(1,0), new Tuple(-1,0), new Tuple(1,-1)},
		{new Tuple(0,0), new Tuple(0,1), new Tuple(0,-1), new Tuple(-1,-1)},
	};


	public Piece( Field f, char type, int col, int rot ) {
		field = f;
		this.type = type;
		this.column = col;
		rotation = rot;

		pieces = piecesFromType( type );
		rotations = pieces.length;
		if( field != null )
			hardDrop();
	}

	private static Tuple[][] piecesFromType( char type ) {
		switch( type ) {
		case 't':
			return TRotationMatrix;
		case 'l':
			return LRotationMatrix;
		case 'i':
			return IRotationMatrix;
		case 'z':
			return ZRotationMatrix;
		case 's':
			return SRotationMatrix;
		case 'o':
			return ORotationMatrix;
		case 'j':
			return JRotationMatrix;
		default: 
			System.err.println("no piece match");	
			return null;
		}
		
	}
	public Piece(Field f, Piece workingPiece, int col, int rot) {
		field = f;
		this.type = workingPiece.type;
		this.column = col;
		rotation = rot;

		pieces = workingPiece.pieces;
		rotations = pieces.length;
		
		if( field != null ) 
			hardDrop();
	}


	public Piece(Piece nextPiece) {

		this.field = nextPiece.field;
		this.type = nextPiece.type;
		this.column = nextPiece.column;
		this.rotation = nextPiece.rotation;
		this.pieces = nextPiece.pieces;
		rotations = pieces.length;

	}

	public static Piece fromBlocks(char type, Tuple[] blocks) {
		Piece ret = null;
		if( (ret = blockMatch( type, blocks )) != null )
			return ret;
		return null;
	}
	
	public static Piece fromBlocks( Tuple[] blocks ) {
		char[] types = new char[] { 't', 's', 'z', 'i', 'o', 'l', 'j' };
		Piece ret = null;
		for( int i = 0; i < types.length; i++ ) {
			ret = blockMatch( types[i], blocks );
			if( ret != null ) return ret;
		}
		return null;
	}
	public Piece(char type_, int col_, int line_, int rot_) {
		field = null; //YEAH THAT's RIGHT LOOK AT IT
		type = type_;
		column = col_;
		line = line_;
		rotation = rot_;
		pieces = piecesFromType( type );
		rotations = pieces.length;
		
	}


	private static Piece blockMatch( char type, Tuple[] blocks ) {
		int line, col;
		//System.out.println("TYPE: "+type);
		//System.out.println("blocks is "+blocks);
		Tuple[][] templates = piecesFromType( type );
		
		for( int rotation = 0; rotation < templates.length; rotation++ ) {
			//if( type == 'i' && rotation == 1 ) continue;
			for( int center = 0; center < 4; center++ ) {
				line = blocks[center].y;
				col = blocks[center].x;
				if( type == 'i' ) System.out.println( "("+col +", "+line+")");
				int i = 0;
				for( i = 0; i < 4; i++ ) {
					if( i == center ) continue;
					Tuple candid = new Tuple( blocks[i].x - col, blocks[i].y - line );
					boolean found =false;
					//System.out.println("candidate: ("+candid.x+", "+candid.y+")");
					for( int j = 0; j < 4; j++ ) {
						if( candid.x != templates[rotation][j].x ) continue;
						if( candid.y != templates[rotation][j].y ) continue;
						found = true;
						break;
					}
					if(!found) break;;
					
					
				}
				if(i < 4) continue;
				
				System.out.println("found it");
				return new Piece( type, col, line, rotation );
			}
		}
		System.out.println("didn't find anything");
		return null;
	}

	public Tuple getPosOfBlock(int idx) {
		return pieces[rotation][idx];
	}


	private void place() {
		for( int i = 0; i < 4; i++ ) {
			field.putBlock( line, column, getPosOfBlock( i ), type );
		}
	}


	public int lowestLeftColumn() {
		int lowCol = Integer.MAX_VALUE;

		for( int i = 0; i < 4; i++ ) {
			Tuple bp = getPosOfBlock( i );
			//if( bp.y > lowLine ) continue;
			//lowLine = bp.y;
			if( bp.x > lowCol ) continue;
			lowCol = bp.x;
		}
		//System.out.println("offs: "+(lowCol - pieces[rotation][0].x)+" = "+lowCol+" - "+pieces[rotation][0].x );
		return lowCol;// + pieces[rotation][0].x;
	}
}
