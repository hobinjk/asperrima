package jk.tet;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


public class Field {
	private List<char[]> field;
	int lines, columns;
	public Field(int lines_, int columns_) {
		lines = lines_;
		columns = columns_;
		field = new ArrayList<char[]>();
		for( int i = 0; i < lines; i++ ) addNewLine();
	}
	private void addNewLine() {
		char[] add = new char[columns];
		for( int i = 0; i < columns; i++ ) {
			add[i] = ' ';
		}
		field.add( add );
	}
	public Field(Field copy) {
		field = new ArrayList<char[]>();
		columns = copy.getColumns();
		lines = copy.getLines();
		
		for( int i = 0; i < copy.getLines(); i++ ) {
			field.add( new char[getColumns()]);
			for( int j = 0; j < copy.getColumns(); j++ ) {
				field.get(i)[j] = copy.getBlock( i, j );
				//if( field.get(i)[j] != ' ' ) System.out.println("true, true");
			}
		}
			
		
	}
	public int getColumns() {
		return columns;
		
	}
	public int getLines() {
		return lines;
	}
	public boolean isPieceInsertableIn( Piece piece ) {
		boolean isInsertable = true;
		
		for( int idx = 0; idx < 4 && isInsertable; idx++ ) {
			Tuple blockPos = piece.getPosOfBlock( idx );
			isInsertable &= ( piece.column + blockPos.x >= 0 && piece.column + blockPos.x < getColumns() ) 
					&& (piece.line + blockPos.y >= 0 && piece.line + blockPos.y < getLines() ) 
					&& (field.get( piece.line + blockPos.y )[ piece.column + blockPos.x ] == ' ');
		}
		return isInsertable;
	}
	public int checkDestroyedLines() {
		int linesDes = 0;
		for( int line = 0; line < field.size(); line++ ) {
			boolean allFull = true;
			for( int col = 0; col < getColumns() && allFull; col++ ) {
				if( field.get(line)[col] == ' ')
					allFull = false;
				
			}
			if(! allFull ) continue;
			destroyLine( line );
			linesDes ++;
			//I dunno anymore
		}
		return linesDes;
		/*
		switch( linesDes ) {
		case 0:
			return 0;
		case 1:
			return 100;
		case 2:
			return 300;
		case 3:
			return 600;
		case 4:
			return 1000;
		default:
			return 0;
		}
		*/
	}
	private void destroyLine( int lne ) {
		field.remove(lne);
		addNewLine();
	}
	public void putBlock(int line, int column, Tuple pos, char type) {
		putBlock( line+pos.y, column+pos.x, type );
	}
	public void putBlock(int line, int column, char type) {
		field.get(line)[column] = type;
	}
	
	public int checkHoles() {
		int holes = 0;
		boolean[] closedLine = new boolean[getColumns()];
		for( int i = 0; i < getColumns(); i++ ) closedLine[i] = false;
		
		for( int line = getLines() - 1; line > -1; line-- ) {
			for( int col = 0; col < getColumns(); col++ ) {
				if( closedLine[col] ) {
					if( getBlock(line,col) == ' ' )
						holes++;
				} else
					closedLine[col] = getBlock(line, col) != ' ';
			}
		}
		//System.out.println(holes+" holes");
		return holes;
	}
	public int checkGaps() {
		int gaps = 0;
		int highestLine = 19;
		
		for( highestLine = getLines() - 1; highestLine > -1; highestLine-- ) {
			boolean found = false;;
			for( int col = 0; col < getColumns(); col++ ) {
				if( isEmpty( highestLine, col ) ) continue;
				found = true;
				break;
			}
			if(! found ) continue;
			break;
		}
		for( int i = highestLine; i > -1; i-- ) {
			for( int col = 0; col < getColumns()-3; col++ ) {
				if( isEmpty( i, col ) ) continue;
				if(! isEmpty( i, col+1 ) ) continue;
				if( isEmpty( i, col+2 ) ) continue;
				gaps++;
			}
		}
		//System.out.println(holes+" holes");
		
		return gaps;
		
	}
	public char getBlock(int line, int col) {
		return field.get(line)[col];
	}
	public void clear() {
		for( char[] line: field ) {
			for( int i = 0; i < line.length; i++ ) {
				line[i] = ' ';
			}
		}
	}
	@Override
	public boolean equals( Object o ) {
		Field other = null;
		try {
			other = (Field)o;
		} catch( ClassCastException javaHatesYou ) {
			return false;
		}
		for( int line = 0; line < getLines(); line++ ) {
			for( int col = 0; col < getColumns(); col++ ) {
				boolean emptyOther = other.getBlock(line,col) == ' ';
				boolean emptyThis = this.getBlock(line,col) == ' ';
				if( !( emptyOther ^ emptyThis ) )
					continue;
				return false;
			}
		}
		return false;
	}
	
	private boolean isEmpty( int line, int col ) {
		if( line < 0 || line > getLines() - 1 ) return true;
		if( col < 0 || col > getColumns() - 1 ) return true;
		
		return getBlock( line, col ) == ' ';
	}
	public Piece findFallingPiece(char type) {
		Field testField = new Field( this );
		for( int line = getLines() - 1; line > -1; line-- ) {
			for( int col = 0; col < getColumns(); col++ ) {
				List<Tuple> fillLocs = testField.floodFill( line, col );
				//if( fillLocs.size() != 0 )
				//System.out.println("effefffed "+fillLocs.size()+" blocks");
				if( fillLocs.size() != 4 ) continue;
				Tuple[] blocks = new Tuple[4];
				fillLocs.toArray(blocks);
				if( type != ' ' )
					return Piece.fromBlocks( type, blocks );
				else 
					return Piece.fromBlocks( blocks );
			}
		}
		return null;
	}
	public Piece findFallingPiece() {
		return findFallingPiece(' ');
	}
	
	public List<Tuple> floodFill( int line, int col ) {
		List<Tuple> ret = new ArrayList<Tuple>();
		if( isEmpty( line, col ) ) return ret;
		LinkedList<Tuple> queue = new LinkedList<Tuple>();
		
		queue.add( new Tuple( col, line )  );
		
		while( !queue.isEmpty() ) { 
			Tuple node = queue.pop();
			if( isEmpty( node.y, node.x ) ) continue;
			Tuple west = new Tuple( node );
			Tuple east = new Tuple( node );
			while(!isEmpty( west.y, west.x ) )
				west.x--;
			
			for( int i = node.x-1; i > west.x; i-- ) {
				ret.add( new Tuple( i, west.y ) );
				putBlock( west.y, i, ' ' );
				if(!isEmpty( west.y+1, i ))
					queue.add( new Tuple( i, west.y+1 ) );
				if(!isEmpty( west.y-1, i ))
					queue.add( new Tuple( i, west.y-1 ) );
			}
			while(!isEmpty( east.y, east.x ) )
				east.x++;
			
			for( int i = node.x; i < east.x; i++ ) {
				ret.add( new Tuple( i, east.y ) );
				putBlock( east.y, i, ' ' );
				if(!isEmpty( east.y+1, i ))
					queue.add( new Tuple( i, east.y+1 ) );
				if(!isEmpty( east.y-1, i ))
					queue.add( new Tuple( i, east.y-1 ) );
			}
			
			//putBlock( node.y, node.x, ' ' );
		}
		
		
		return ret;
	}
}