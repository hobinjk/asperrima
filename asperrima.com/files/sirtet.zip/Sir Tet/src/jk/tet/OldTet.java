package jk.tet;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import processing.core.PApplet;

public class OldTet extends PApplet {
	private static final long serialVersionUID = 1L;
	private static final int KEY_DELAY = 75;
	
	
	Robot robot;
	int gameX, gameY;
	Piece currentPiece;
	Field field = new Field(20,10);
	State state = State.FIND_GAME;
	
	private enum State {
		FIND_GAME, FIND_PIECE, PLACE_PIECE, FIND_FIELD
	};
	BufferedImage iImage, jImage, lImage, oImage, sImage, tImage, zImage;
	private int offsHeight;
	private BufferedImage holdImage;
	int startX = 4;
	private boolean updating = true;
	public OldTet() {
		try {
			iImage = ImageIO.read(new File("data/i.png"));
			jImage = ImageIO.read(new File("data/j.png"));
			lImage = ImageIO.read(new File("data/l.png"));
			oImage = ImageIO.read(new File("data/o.png"));
			sImage = ImageIO.read(new File("data/s.png"));
			tImage = ImageIO.read(new File("data/t.png"));
			zImage = ImageIO.read(new File("data/z.png"));
			holdImage = ImageIO.read(new File("data/hold.png"));
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			robot = new Robot();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		
	}
	public static void main( String[] args ) {
		PApplet.main( new String[] { "jk.tet.OldTet" } );
		/*Tet tet = new Tet();
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
			tet.update();	*/
		
	}
	public void setup() {
		size(180,360);
		stroke(128);
		/*
		updating = false;
		
		new Piece( field, 'i', startX, 0 );
		new Piece( field, 'i', startX, 0 );
		new Piece( field, 'i', startX, 1 );
		new Piece( field, 'i', startX, 0 );
		new Piece( field, 'i', startX, 2 );
		new Piece( field, 'i', startX, 0 );
		new Piece( field, 'i', startX, 3 );
		*/
	}
	public void draw() {
		update();
		
		for( int line = 0; line < field.getLines(); line++ ) {
			for( int col = 0; col < field.getColumns(); col++ ) {
				switch( field.getBlock( line, col ) ) {
				case ' ':
					fill(0);
					break;
				case 't':
					fill(255,0,200);
					break;
				case 'z':
					fill(255,0,0);
					break;
				case 's':
					fill(0,255,0);
					break;
				case 'i':
					fill(50,50,255);
					break;
				case 'o':
					fill(255,255,0);
					break;
				case 'l':
					fill(255,127,0);
					break;
				case 'j':
					fill(0,0,200);
					break;
					
				}
				rect(col*18,(field.getLines()-1-line)*18,18,18);
			}
		}
	}
	
	void update() {
		if( ! updating ) return;
		switch( state ) {
		case FIND_GAME:
			System.out.println("finding game");
			findGame();
			break;
		case FIND_PIECE:
			System.out.println("finding piece");
			findPiece();
			break;
		case PLACE_PIECE:
			System.out.println("placing piece");
			placePiece();
			break;
		}
		
		
	}
	void findGame() {
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		
		int[] coords = find( holdImage, screenCap( 0,0, screen.width, screen.height ));
		if( coords == null ) return;
		
		gameX = coords[0];
		gameY = coords[1];
		System.out.println("Coords located");
		state = State.FIND_PIECE;
		
		
	}
	BufferedImage screenCap( int x, int y, int w, int h ) {
		Rectangle captureRegion = new Rectangle( new Point( x, y ), new Dimension( w, h ) );
		BufferedImage bi = robot.createScreenCapture(captureRegion);
		return bi;
		
	}
	void findPiece() {
		//press( KeyEvent.VK_DOWN );
		//press( KeyEvent.VK_DOWN );
		
		BufferedImage capture = screenCap( gameX+100, gameY+offsHeight , 200, 200 );
		//displayImage( capture );
		char type = ' ';
		if( exists( iImage, capture ) ) 
			type = 'i';
		else if( exists( jImage, capture ) )
			type = 'j';
		else if( exists( lImage, capture ) )
			type = 'l';
		else if( exists( oImage, capture ) )
			type = 'o';
		else if( exists( sImage, capture ) )
			type = 's';
		else if( exists( zImage, capture ) )
			type = 'z';
		else if( exists( tImage, capture ) )
			type = 't';
		else {
			System.err.println("didn't find anything");
			return;
		}
		currentPiece = new Piece( new Field(field), type, startX, 0 );
		
		state = State.PLACE_PIECE;
		
	}
	
	private boolean exists( BufferedImage template, BufferedImage cap) {
		return find( template, cap ) != null;
	}
	private int[] find( BufferedImage templateIcky, BufferedImage capIcky ) {
		BufferedImage template = new BufferedImage( templateIcky.getWidth(), templateIcky.getHeight(), BufferedImage.TYPE_INT_RGB );
		BufferedImage cap = new BufferedImage( capIcky.getWidth(), capIcky.getHeight(), BufferedImage.TYPE_INT_RGB );
		template.getGraphics().drawImage(templateIcky, 0, 0, null);
		cap.getGraphics().drawImage(capIcky, 0, 0, null);
		
		for( int x = 0; x < cap.getWidth()-template.getWidth()+1; x++ ) {
			for( int y = 0; y < cap.getHeight()-template.getHeight()+1; y++ ) {
				boolean good = true;
				for( int tx = 0; tx < template.getWidth() && good; tx++ ) {
					for( int ty = 0; ty < template.getHeight() && good; ty++ ) {
						int tplRGB = template.getRGB( tx, ty );
						int capRGB = cap.getRGB( x+tx, y+ty );
						
						if( Math.abs(blue(tplRGB) - blue(capRGB)) > 50 ) {
							good = false;
							break;
						}
						if( Math.abs(red(tplRGB) - red(capRGB)) > 50 ) {
							good = false;
							break;
						}
						if( Math.abs(green(tplRGB) - green(capRGB)) > 50 ) {
							good = false;
							break;
						}
						//displayImage( cap.getSubimage( x, y, template.getWidth(), template.getHeight() ));
						
						
						
					}
				}
				if( good ) return new int[] { x, y };
			}
		}
		return null;
	}
	/*
	public int blue( int rgb ) {
		return rgb & 0xff;
	}
	public int red( int rgb ) {
		return ( rgb >> 16 ) & 0xff;
	}
	public int green( int rgb ) {
		return ( rgb >> 8 ) & 0xff;
	}
	*/
	void placePiece() {
		
		float leastScore = Float.MAX_VALUE;
		Piece least = null;
		System.out.println(field.getColumns());
		for( int col = 0; col < field.getColumns(); col++ ) {
			for( int rot = 0; rot < currentPiece.rotations; rot++ ) {
				//System.out.println("wooo");
				Piece piece = new Piece( new Field( field ), currentPiece, col, rot );
				if( !piece.valid ) {
					//System.out.println("inconceivable");
					continue;
				}
				if( leastScore < piece.score ) continue;
				System.out.println("#1 in points: "+leastScore);
				leastScore = piece.score;
				least = piece;
			}
		}
		if( least == null ) {
			System.out.println("derp you lose");
			updating = false;
			return;
		}
		System.out.println("best is "+least.type+" at col: "+least.column+" and rot: "+least.rotation+" with score "+least.score);
		place( least );
		field = least.field;
		state = State.FIND_PIECE;
		
	}

	private void press( int key ) {
		press( key, KEY_DELAY );
	}
	private void press( int key, int keyDelay ) {
		press( key, keyDelay, keyDelay/2 );
	}
	private void press( int key, int keyDelayUp, int keyDelayDown ) {
		robot.keyPress( key );
		try {
			Thread.sleep(keyDelayUp);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		robot.keyRelease( key );
		try {
			Thread.sleep(keyDelayDown);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	private void place(Piece least) {
		while( currentPiece.rotation < least.rotation ) {
			currentPiece.rotation ++;
			System.out.println("poke");
			press( KeyEvent.VK_UP, 200, 100 );
		}
		//least.column -= least.getPosOfBlock(0).x;
		
		int key = currentPiece.column - least.column > 0 ? KeyEvent.VK_LEFT : KeyEvent.VK_RIGHT;
		while( least.column - currentPiece.column != 0 ) {
			press( key, 100, 50 );
			currentPiece.column += currentPiece.column < least.column ? 1 : -1;
		}
		
		press( KeyEvent.VK_SPACE, 100, 10 );
	}
	
	public void displayImage( BufferedImage bi ) {
		ImageIcon ii = new ImageIcon();
		ii.setImage( bi );
		JOptionPane.showMessageDialog(null, ii);
	}
	
}
