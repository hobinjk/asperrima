package jk.tet;

public class Tuple {
	int x, y;
	public Tuple( int x, int y ) {
		this.x = x;
		this.y = y;
	}
	public Tuple( Tuple other ) {
		this.x = other.x;
		this.y = other.y;
	}
}
