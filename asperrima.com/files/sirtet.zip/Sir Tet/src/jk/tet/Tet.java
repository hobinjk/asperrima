package jk.tet;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Tet implements Runnable {
	//private static final int KEY_DELAY = 75;


	private static final boolean D = false;


	public Robot robot;
	public Piece currentPiece, nextPiece, leastCurrent, leastNext;
	public Field field = new Field(20,10);
	public State state = State.FIND_GAME;

	private enum State {
		FIND_GAME, FIND_PIECES, PLACE_PIECE, FIND_NEXT_PIECE, FIND_FIELD
	};
	private enum Place {
		VISUAL, DEFAULT, FALLING
	};

	private Place piecePlaceMode = Place.FALLING;

	int startX = 4;
	private boolean updating = true;
	GameInfoFinder gif;


	Field debugField = new Field(20,10);;
	public Tet() {
		try {
			robot = new Robot();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		gif = new GameInfoFinder( robot );

	}

	@Override
	public void run() {
		while( updating )
			update();
	}
	void update() {
		if( ! updating ) return;
		switch( state ) {
		case FIND_GAME:
			if(D) System.out.println("finding game");
			if( gif.findGame() )
				state = State.FIND_PIECES;
			break;
		case FIND_PIECES:
			if(D) System.out.println("finding pieces");
			findPieces();
			findLeast();
			break;
		case PLACE_PIECE:
			if(D) System.out.println("placing piece");
			placeCurrentPiece( );
			break;
		case FIND_NEXT_PIECE:
			if(D) System.out.println("finding next piece");

			debugField = leastCurrent.field;
			currentPiece = new Piece( nextPiece );
			nextPiece = gif.findNextPiece( );
			findLeast();

			state = State.PLACE_PIECE;
			break;
		case FIND_FIELD:
			//System.out.println("finding field");
			field = gif.findField( leastCurrent.field );
			if(!debugField.equals( field ) ) {
				//System.out.println("that failed with a "+currentPiece.type);
				debugField = new Field( field );
			}
			state = State.FIND_NEXT_PIECE;
			break;
		}


	}
	void findPieces() {
		//press( KeyEvent.VK_DOWN );
		//press( KeyEvent.VK_DOWN );
		while( currentPiece == null ) {
			//System.out.println("finding the current");
			currentPiece = gif.findCurrentPiece( );
		}
		//System.out.println("finding the next");
		nextPiece = gif.findNextPiece( );

		//System.out.println(currentPiece == null ? "OH LAWD" : "NVM YR FINE");
		state = State.PLACE_PIECE;
	}

	void findLeast() {
		float leastScore = Float.MAX_VALUE;
		leastCurrent = null;
		leastNext = null;

		//System.out.println("curt: "+currentPiece.type+"  nextt: "+nextPiece.type);
		//System.out.println(field.getColumns());
		for( int colCur = -1; colCur < field.getColumns()+1; colCur++ ) {
			for( int rotCur = 0; rotCur < currentPiece.rotations; rotCur++ ) {
				//System.out.println("wooo");
				//if( rotCur == 1 && currentPiece.type == 'i' ) continue;

				Piece cPiece = new Piece( new Field( field ), currentPiece, colCur, rotCur );
				if( !cPiece.valid )
					continue;

				//if( cPiece.score > leastScore ) continue;
				for( int colNext = -1; colNext < field.getColumns()+1; colNext++ ) {
					for( int rotNext = 0; rotNext < nextPiece.rotations; rotNext++ ) {
						//if( rotNext == 1 && nextPiece.type == 'i' ) continue;

						Piece nPiece = new Piece( new Field( cPiece.field ), nextPiece, colNext, rotNext );
						if( !nPiece.valid ) continue;
						
						if( leastScore < cPiece.score + nPiece.score ) continue;
						//System.out.println("BEFORE: "+leastScore);
						leastScore = cPiece.score + nPiece.score;
						//System.out.println("AFTER:: "+leastScore);
						leastNext = nPiece;
						leastCurrent = cPiece;
					}
				}

			}
		}
		if( leastNext == null || leastCurrent == null ) {
			System.out.println("derp you lose");
			state = State.FIND_FIELD;
			return;
		}
		//System.out.println("gaps: "+leastCurrent.score);
		//System.out.println("current best is "+leastCurrent.type+" at col: "+leastCurrent.column+" line: "+leastCurrent.line+" and rot: "+leastCurrent.rotation+" with score "+leastCurrent.score);
		//System.out.println("least best is "+leastNext.type+" at col: "+leastNext.column+" line: "+leastNext.line+" and rot: "+leastNext.rotation+" with score "+leastNext.score);

	}

	void placeCurrentPiece() {
		place( leastCurrent );
		leastCurrent.field = debugField;
		leastCurrent.hardDrop();

		state = State.FIND_FIELD;
		/*
		if( leastNext == null ) {
			state = State.FIND_FIELD;
		} else {
			leastCurrent = new Piece( leastNext );
			leastNext = null;
			currentPiece = new Piece( nextPiece );
			nextPiece = null;

			state = State.PLACE_PIECE;
		}
		 */
	}

	/*
	private void press( int key ) {
		press( key, KEY_DELAY );
	}

	private void press( int key, int keyDelay ) {
		press( key, keyDelay, keyDelay/2 );
	}
	 */
	private void press( int key, int keyDelayUp, int keyDelayDown ) {
		robot.keyPress( key );
		try {
			Thread.sleep(keyDelayUp);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		robot.keyRelease( key );
		try {
			Thread.sleep(keyDelayDown);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	private void place(Piece least) {
		boolean debug = false;
		if( least.type == 'i' ) {
			System.out.println("IT'S ON NOW ULTIMATE GRUDGE MATCH");
			debug = true;
			//least.column += 1; //THIS IS SO STUPID
		}

		if( piecePlaceMode != Place.FALLING ) {
			if( least.rotation == 3 ) {
				//delay( 50 );
				currentPiece.rotation = 3;
				press( KeyEvent.VK_Z, 100, 100 );
			} else {
				while( currentPiece.rotation < least.rotation ) {
					//delay( 50 );
					currentPiece.rotation ++;
					//System.out.println("poke");
					press( KeyEvent.VK_X, 100, 100 );
				}
			}
			if( debug )
				System.out.println(currentPiece.rotation);
		}//least.column -= least.getPosOfBlock(0).x;

		debug = true;
		boolean acquired = false;
		boolean reacquiring = false;

		while( true ) {
			if( piecePlaceMode == Place.VISUAL ) {
				int colOffset = least.lowestLeftColumn();
				if( debug ) System.out.println("offs: "+colOffset);

				int pieceCol = gif.findLeftMostPieceColumn();
				if( debug ) 
					System.out.println( pieceCol + " = "+least.column+ " ? "+colOffset+" ? "+least.getPosOfBlock(0).x );

				int key = pieceCol - (least.column+colOffset) > 0 ? KeyEvent.VK_LEFT : KeyEvent.VK_RIGHT;
				press( key, 50, 50 );
				//delay(20);
				pieceCol = gif.findLeftMostPieceColumn();
				if( pieceCol - (least.column+colOffset) == 0 ) break;
			} else if( piecePlaceMode == Place.DEFAULT ) {
				int key = currentPiece.column - least.column > 0 ? KeyEvent.VK_LEFT : KeyEvent.VK_RIGHT;
				press( key, 75, 50 );
				//delay(20);
				currentPiece.column += currentPiece.column - least.column > 0 ? -1 : 1;
				debugField = gif.findFieldLimit(0);
				Piece p = debugField.findFallingPiece();
				if( p != null )
					System.out.println(p.column+" = "+currentPiece.column+" and "+p.rotation+" = "+currentPiece.rotation);
				if( currentPiece.column == least.column ) {
					//int colOffset = least.lowestLeftColumn();
					//int pieceCol = gif.findLeftMostPieceColumn()-colOffset;

					//if( debug ) System.out.println( least.type + ": " + pieceCol + " = "+least.column+ " ? "+colOffset+" ? "+least.getPosOfBlock(0).x );
					break;
				}

			} else 
				if( piecePlaceMode == Place.FALLING ){	
					//delay(20);
					//currentPiece.column += currentPiece.column - least.column > 0 ? -1 : 1;
					//Timer.start();
					if(!acquired) {
						debugField = gif.findFieldLimit(0);
						Piece p = debugField.findFallingPiece( currentPiece.type );
						if( p == null ) {
							if( debug )  System.out.println("nope");
							continue;
						}
						if( debug ) System.out.println("acquired");
						/*if( p.type != currentPiece.type ) {
							state = State.FIND_PIECES;
							System.out.println("UH OH");
							return;
						}*/
						currentPiece = p;
						if( debug ) {
							System.out.println("cp: "+currentPiece.column+", "+currentPiece.line+", "+currentPiece.rotation );
							System.out.println("lp: "+least.column+", "+least.line+", "+least.rotation);
						}
						acquired = true;
						if( currentPiece.column == least.column && currentPiece.rotation == least.rotation ) {
							break;
						} else {
							System.out.println("notequal");
						}
					}
					
					if(!acquired) {
						if(reacquiring) {
							state = State.FIND_PIECES;
							if( debug ) System.out.println("uh oh it's rac");
							return;
						}
						continue;
						
					}
					


					//Timer.end( "findField" );
					//Timer.start();
					//Timer.end( "findPiece" );
					//System.out.println("cp: "+currentPiece.column+" ? "+least.column );
					if( debug ) System.out.println("col: "+currentPiece.column +" == "+least.column);
					if( debug ) System.out.println("rot: "+currentPiece.rotation +" == "+least.rotation);

					if( currentPiece.column == least.column && currentPiece.rotation == least.rotation ) {
						acquired = false;
						reacquiring = true;
						if( debug ) System.out.println("reacquiring");
					}

					if( currentPiece.column != least.column ) {
						int key = currentPiece.column - least.column > 0 ? KeyEvent.VK_LEFT : KeyEvent.VK_RIGHT;
						press( key, 50, 30 );
						currentPiece.column += currentPiece.column - least.column > 0 ? -1: 1;
					}
					if( currentPiece.rotation != least.rotation ) {
						press( KeyEvent.VK_Z, 100, 100 );
						currentPiece.rotation = (currentPiece.rotation + 1) % currentPiece.rotations; 
					}


				}
		}
		//delay( 100 );
		press( KeyEvent.VK_SPACE, 100, 200 );
		//debugField  = currentPiece.field;
		//delay( 10 );

	}

	public void displayImage( BufferedImage bi ) {
		ImageIcon ii = new ImageIcon();
		ii.setImage( bi );
		JOptionPane.showMessageDialog(null, ii);
	}
}
