package jk.tet;

import processing.core.PApplet;

public class TetRunner extends PApplet {
	private static final long serialVersionUID = 1L;
	Tet tet;
	public static void main( String[] args ) {
		PApplet.main( new String[] { "jk.tet.TetRunner" } );
	}
	public void setup() {
		size(360,360);
		stroke(128);
		tet = new Tet();
		//tet.updating = false;
		
		//new Piece( tet.field, 'i', 4, 1 );
		/*new Piece( field, 'i', startX, 0 );
		new Piece( field, 'i', startX, 1 );
		new Piece( field, 'i', startX, 0 );
		new Piece( field, 'i', startX, 2 );
		new Piece( field, 'i', startX, 0 );
		new Piece( field, 'i', startX, 3 );
		updating = false;
		debugField = new Field( field );*/
		//System.out.println(tet.field.checkGaps());
		//System.out.println( field.floodFill( 0, 5 ).size() );
		
		new Thread( tet ).start();
		
	}
	public void draw() {
		//tet.update();
		/*
		if( currentPiece != null )
			System.out.println("c piece: "+currentPiece.type);
		if( nextPiece != null )
			System.out.println("n piece: "+nextPiece.type);
		*/
		for( int line = 0; line < tet.field.getLines(); line++ ) {
			for( int col = 0; col < tet.field.getColumns(); col++ ) {
				switch( tet.field.getBlock( line, col ) ) {
				case ' ':
					fill(0);
					break;
				case 't':
					fill(255,0,200);
					break;
				case 'z':
					fill(255,0,0);
					break;
				case 's':
					fill(0,255,0);
					break;
				case 'i':
					fill(50,50,255);
					break;
				case 'o':
					fill(255,255,0);
					break;
				case 'l':
					fill(255,127,0);
					break;
				case 'j':
					fill(0,0,200);
					break;
					
				}
				rect(col*18,(tet.field.getLines()-1-line)*18,18,18);
				switch( tet.debugField.getBlock( line, col ) ) {
				case ' ':
					fill(0);
					break;
				case 't':
					fill(255,0,200);
					break;
				case 'z':
					fill(255,0,0);
					break;
				case 's':
					fill(0,255,0);
					break;
				case 'i':
					fill(50,50,255);
					break;
				case 'o':
					fill(255,255,0);
					break;
				case 'l':
					fill(255,127,0);
					break;
				case 'j':
					fill(0,0,200);
					break;
					
				}
				rect(col*18+180,(tet.debugField.getLines()-1-line)*18,18,18);
			}
		}
	}
	
}
